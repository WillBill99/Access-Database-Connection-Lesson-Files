import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;

public class Insertion_Example{

	public static void main (String [] args)
	{
		try {
		Scanner Keyboard = new Scanner(System.in);
		String Member_ID = " ";
		String MemberType = " ";
		
		String DatabaseURL = "jdbc:ucanaccess://C://Programming Files//Test_Membership_Database.accdb ";
		Connection Con = DriverManager.getConnection(DatabaseURL);
		Statement State = Con.createStatement();
		
		System.out.print("Hello New Member!" +'\n' + "Please enter your Name: ");
		Member_ID = Keyboard.next();
		System.out.print("Enter your Membership Type: ");
		MemberType = Keyboard.next();
		
		int Monthly_Payment = 150;
		double Amount_Paid = 0;
		System.out.print("What would you like to pay currently?: ");
		Amount_Paid = Keyboard.nextDouble();
		double Amount_Due = Monthly_Payment - Amount_Paid;
		
		String SQLQuery = ("INSERT INTO Membership_Table (Member_ID, Member_Name, Membership_Type, Monthly_Payment, Ammount_Paid, Ammount_Due) VALUES '2', '" + Member_ID + "' , '" + MemberType + "' , '" + Monthly_Payment + "' , '" + Amount_Paid + "' , '" + Amount_Due +"'");
		State.executeUpdate(SQLQuery);
		
		System.out.println("Test" );
		
		}catch (Exception ex)
		{
			System.out.println(ex);
		}
	}
}
