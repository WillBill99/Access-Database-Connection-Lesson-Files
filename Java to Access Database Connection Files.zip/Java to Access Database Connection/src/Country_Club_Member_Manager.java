/*Program Name: Country Club Member Manager
 * Date: 3/24/2019
 * Purpose: To show how you can connect to and modify an access database. 
 */
import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;

public class Country_Club_Member_Manager {
	private static Scanner Keyboard = new Scanner(System.in);
	
	public static void main(String[] args) {
			String Member_Name = " ";
			
			//This retrieves the member's name, and determines if it needs to make a new member. 
			System.out.print("Welcome member!" + '\n' + "''If you are new to the club, please type NEW into the program.''" + '\n' +
							"Please enter your first name: " );
			Member_Name = Keyboard.nextLine();
			if(Member_Name.equals("new") || Member_Name.equals("NEW"))
			{
				new_Member();
			}else
			{
				current_Member(Member_Name);
			}
				
		}
	private static void new_Member()
	{
		try {
			//This declares the variables needed for the insertion query.
			String Member_Name = " ";
			String Decision = "";
			String MemberType = " ";
			int Monthly_Payment = 0;
			double Amount_Paid = 0;
			boolean Membership_Decision = false;
			
			//This declares the pathway to the database, and then uses the pathway to connect to the database.
			String DatabaseURL = "jdbc:ucanaccess://C://Programming Files//Test_Membership_Database.accdb ";
			Connection Con = DriverManager.getConnection(DatabaseURL);
			Statement State = Con.createStatement();
			
			//This gathers the information on the new member.
			System.out.print("Hello New Member!" +'\n' + "Please enter your Name: ");
			Member_Name = Keyboard.nextLine();
			System.out.print("Select your Membership Type(Bronze, Silver, Gold, Platinum): ");
			MemberType = Keyboard.nextLine();
			
			//This determines what membership the person will have based off of their input.
			do
			{
				if(MemberType.equals("Bronze"))
				{
					Monthly_Payment = 10;
				}else if(MemberType.equals("Silver"))
				{
					Monthly_Payment = 50;
				}else if(MemberType.equals("Gold"))
				{
					Monthly_Payment = 100;
				}else
				{
					Monthly_Payment = 150;
				}
			
				//This block of code verifies that the member is getting the plan they want. 
				System.out.print("You have chosen the " + MemberType + " membership type, which means that your monthly payment will be: $" + Monthly_Payment + "." + '\n' +
								 "Is this a good payment for you? (Y/N): ");
				Decision = Keyboard.nextLine();
				Decision.toLowerCase();
				if (Decision.equals("y") || Decision.equals("yes"))
				{
					Membership_Decision = true;
				}else
				{
					Membership_Decision = false;
				}
				
			} while (Membership_Decision = false);
			
			//This finalizes the information that the new member has entered.
			System.out.print("What would you like to pay at the moment?: ");
			Amount_Paid = Keyboard.nextDouble();
			double Amount_Due = Monthly_Payment - Amount_Paid;
			double Member_ID = Math.random() * 100;
			
			//This block of code enters the new member into the database, and then closes the database.
			String SQLQuery = ("INSERT INTO Membership_Table (Member_ID, Member_Name, Membership_Type, Monthly_Payment, Amount_Paid, Amount_Due)" +
								" VALUES '" + Member_ID +"', '" + Member_Name + "' , '" + MemberType + "' , '" + Monthly_Payment + "' , '" + Amount_Paid + "' , '" + Amount_Due +"'");
			State.executeUpdate(SQLQuery);
			System.out.println("Entry Complete! Welcome to the club.");
			Con.close();
			}catch (Exception ex)
			{
				System.out.println(ex);
			}
	}
	
	private static void current_Member(String Member_Name)
	{
		try
		{
			//This declares the variables for the method. 
			String Member_Info[] = new String [6];
			String DatabaseURL = "jdbc:ucanaccess://C://Programming Files//Test_Membership_Database.accdb ";
			String Upgrade_Decision = "";
			Connection Con = DriverManager.getConnection(DatabaseURL);
			Statement State = Con.createStatement();
			
			//(Lines 111- 135) These queries retrieve the member's information from the database. 
			String SQL_Statement = "SELECT Member_ID FROM Membership_Table WHERE Member_Name = '" + Member_Name + "'";
			ResultSet Result = State.executeQuery(SQL_Statement);
			Result.next();
			Member_Info[0] = Result.getString(1);
	
			SQL_Statement = "Select Membership_Type From Membership_Table Where Member_Name = '" + Member_Name + "'";
			Result = State.executeQuery(SQL_Statement);
			Result.next();
			Member_Info[1] = Result.getString(1);
	
			SQL_Statement = "Select Monthly_Payment From Membership_Table Where Member_Name = '" + Member_Name + "'";
			Result = State.executeQuery(SQL_Statement);
			Result.next();
			Member_Info[2] = Result.getString(1);
	
			SQL_Statement = "Select Amount_Paid From Membership_Table Where Member_Name = '" + Member_Name + "'";
			Result = State.executeQuery(SQL_Statement);
			Result.next();
			Member_Info[3] = Result.getString(1);
	
			SQL_Statement = "Select Amount_Due From Membership_Table Where Member_Name = '" + Member_Name + "'";
			Result = State.executeQuery(SQL_Statement);
			Result.next();
			Member_Info[4] = Result.getString(1);
			
			//This prints out the member's information for them to see.
			System.out.println("Welcome back " + Member_Name + "! (Your ID is " + Member_Info[0] + ")" + '\n' + 
						"You are currently a " + Member_Info[1] + " member, which means that your monthly payment is currently: $" + Member_Info[2] + "." + '\n'+
						"You have paid $" + Member_Info[3] + " of the $" + Member_Info[2] +", meaning that you currently owe $" + Member_Info[4] +
						" to the club." + '\n');
			
			//This determines if the member wants to upgrade their membership, and then acts upon the response.
			System.out.print("While we're reviwing your informaion, would you like to upgrade your membership? (Y/N): ");
			Upgrade_Decision = Keyboard.nextLine();
			if(Upgrade_Decision.equals("yes") || Upgrade_Decision.equals("y") || Upgrade_Decision.equals("Yes") || Upgrade_Decision.equals("Y"))
			{
				Member_Info[1] = membership_Upgrade(Member_Info[1], Member_Info[3], Member_Name);
				System.out.println("Upgrade Complete! " + '\n' + "You are now a " + Member_Info[1] + " Member!");
			}else
			{
				System.out.println("Well, thank you for your consideration!");
			}
			
			Con.close();
			Keyboard.close();
		}catch(Exception ex) {
			System.out.println(ex);
		}
	}
	
	private static String membership_Upgrade(String Membership_Type, String currently_Paid, String Member_Name)
	{	
		String new_Membership_Type = "";
		try
		{
			//This declares the variables for the new information we will gather in this method. 
			String Upgrade = "";
			String decision = "";
			int Monthly_Payment = 0;
			double Currently_Paid = Double.parseDouble(currently_Paid);
			double New_Amount_Due = 0;
			boolean decided = false;
		
			//This determines what the user would like to upgrade/downgrade their membership to.
			do {
				System.out.print("What would you like to upgrade to?(Silver, Gold or Platinum): ");
				Upgrade = Keyboard.nextLine();
		
				if(Upgrade.equals("Silver") || Upgrade.equals("silver"))
				{
					new_Membership_Type = "Silver"; 
					Monthly_Payment = 50;
					New_Amount_Due = Monthly_Payment - Currently_Paid;
				}else if(Upgrade.equals("Gold") || Upgrade.equals("gold"))
				{
					new_Membership_Type = "Gold";
					Monthly_Payment = 100;
					New_Amount_Due = Monthly_Payment - Currently_Paid;
				}else if(Upgrade.equals("Platinum") || Upgrade.equals("platinum"))
				{
					new_Membership_Type = "Platinum";
					Monthly_Payment = 150;
					New_Amount_Due = Monthly_Payment - Currently_Paid;
				}
			
				//This prints out custom statements based on what the result of the New_Amount_Due calculation. 
				if(New_Amount_Due >= 0)
				{
					System.out.print("Your payment will increase each month to :$" + Monthly_Payment+ ". You've paid $" + Currently_Paid +" so far, so $" + New_Amount_Due + " will be due this month." + '\n' +
										"Is this okay for you?(Y/N): ");
				}else
				{
					System.out.print("Your payment will increase each month to :$" + Monthly_Payment+ ". You've paid $" + Currently_Paid +" so far, so $" + New_Amount_Due + " will be refunded to you this month." + '\n' +
										"Is this okay for you?(Y/N): ");
				}
			
				//This finalizes the users upgrade, and then updates their information in the database. 
				decision = Keyboard.nextLine();
				if (decision.equals("yes") || decision.equals("y") || decision.equals("Y") || decision.equals("Yes"))
				{
					String DatabaseURL = "jdbc:ucanaccess://C://Programming Files//Test_Membership_Database.accdb ";
					Connection Con = DriverManager.getConnection(DatabaseURL);
					Statement State = Con.createStatement();
					String SQL_Statement = "UPDATE Membership_Table SET Membership_Type = '"+ new_Membership_Type +"', Monthly_Payment = '"+Monthly_Payment+"', Amount_Due = '"+New_Amount_Due+"' WHERE Member_Name = '"+ Member_Name +"'";
					State.executeUpdate(SQL_Statement);
					System.out.println("Updated.");
					decided = true;
				}else 
				{
					decided = false;
				}
				}while(decided = false);
		
			
		}catch(Exception ex)
		{
			System.out.println(ex);
		}
		return new_Membership_Type;
		}
}
