import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;

public class Update_Example {

	public static void main(String[] args) {
		try {
		Scanner Keyboard = new Scanner(System.in);
		double New_Amount_Due = 150;
		String Answer = "";
		
		System.out.print("Welcome William! Would you like to upgrade your account to Platinum status? (Y/N): ");
		Answer = Keyboard.next();
		
		if (Answer.equals("y") || Answer.equals("Y")) {
			String DatabaseURL = "jdbc:ucanaccess://C://Programming Files//Test_Membership_Database.accdb ";
			Connection Con = DriverManager.getConnection(DatabaseURL);
			Statement State = Con.createStatement();
			String SQl_Statement = "UPDATE Membership_Table SET Membership_Type = 'Gold', Monthly_Payment = '150', Ammount_Due = '100' WHERE Member_Name = 'William'  ";
			State.executeUpdate(SQl_Statement);
			System.out.println("Updated.");
		}
		
		}catch(Exception ex) {
			System.out.println(ex);
		}
	}

}
